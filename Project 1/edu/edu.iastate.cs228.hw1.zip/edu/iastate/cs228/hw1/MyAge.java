package edu.iastate.cs228.hw1;

/**
 *  
 * @author
 *
 */

/**
 * 
 * To be implemented by the Animal class. 
 *
 */
public interface MyAge 
{
	int myAge();	// return age of the animal
}
